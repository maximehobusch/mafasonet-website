import java.io.*;
import java.net.*;
import java.util.*;
public class Webserver {
	File dir;
	int port;
	ServerSocket server;
	Socket socket = null;
	public Webserver(int p, String d) throws java.io.IOException {// create an web server
		port = p;
		dir = new File(d);
		if (!dir.exists()) throw new IOException("the root folder does not exist");
		if (!dir.isDirectory()) throw new IOException("The root folder is a file");

		server = new ServerSocket(port);
	}
	public void start() {// Starts the web server. Am best in the thread run
		Terminal.println("Server is running");
		while (true) {
			try {
				socket = server.accept();
				socket.setSoTimeout(999999999);
				communicate(socket);
			} catch (Exception e) {
				Terminal.printException(e);
				if (socket != null) {
	 				try {
						socket.close();
					} catch (Exception e2) {
						Terminal.printException(e2);
					}
				}
			}
		}
	}
	public void close() {// close the web server
		try {
			socket.close();
			server.close();
		} catch (Exception e) {
			Terminal.println("Error closing the server");
			Terminal.printException(e);
		}
	}
	private void communicate(Socket socket) throws java.io.IOException {
			BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			BufferedOutputStream out = new BufferedOutputStream(socket.getOutputStream());
			new Thread(new Kommunikator(in,out,dir)).start();
	}
	
	
	public static void main(String[] args) throws java.io.IOException {// first parameter port, second root_dir
		int port = -1;
		String root_dir = "";
		Scanner sc = new Scanner(System.in);
		if (args.length < 1) {
			while (port < 0) {
				Terminal.println("please enter positive integer");
				try {
					Terminal.print("Port:");
					port = Integer.parseInt(sc.nextLine());
					
				} catch (NumberFormatException e) {}
			}
			Terminal.println("");
		} else {
			port = Integer.parseInt(args[0]);
		}
		if (args.length < 2) {
			Terminal.print("Root directory of the server:");
			root_dir = sc.nextLine();
			Terminal.println("You can start the Server with this command: \"java -jar <locationJarArchive> " + port + " " + root_dir + "\"");
		} else {
			root_dir = args[1];
		}
		sc.close();
		Webserver webs = new Webserver(port,root_dir);
		webs.start();
	}
}
