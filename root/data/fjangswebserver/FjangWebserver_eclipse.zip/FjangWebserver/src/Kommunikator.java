import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.BufferedOutputStream;
import java.util.*;
public class Kommunikator implements Runnable {// is responsible for the HTTP communication with the client
	private static Hashtable<String,String> DATA_TYPES;
	private static String DEFAULT_DATA_TYPE = "application/octet-stream";
	private static String DEBUG_TERMINAL_PATH = "/serverterminal.html";
	static {
		DATA_TYPES = new Hashtable<String,String>();
		DATA_TYPES.put(".txt", "text/plain; charset=utf-8");
		DATA_TYPES.put(".html", "text/html; charset=utf-8");
		DATA_TYPES.put(".json", "text/json; charset=utf-8");
		DATA_TYPES.put(".js", "text/javascript; charset=utf-8");
		DATA_TYPES.put(".css", "text/css; charset=utf-8");
	
		DATA_TYPES.put(".png", "image/png");
		DATA_TYPES.put(".jpg", "image/jpeg");
		DATA_TYPES.put(".jpeg", "image/jpeg");
		DATA_TYPES.put(".gif", "image/gif");
		DATA_TYPES.put(".svg", "image/svg");

		DATA_TYPES.put(".zip", "application/zip");
		DATA_TYPES.put(".jar", "application/java-archive");
	}
	static String findDataType(File f) {// finds the right type of a datum
		String fname = f.getName();
		int dotSign = fname.lastIndexOf(".");
		if (dotSign == -1) dotSign = fname.length();
		String dtype = DATA_TYPES.get(fname.substring(dotSign,fname.length()));
		if (dtype == null) return DEFAULT_DATA_TYPE;
		return dtype;
	}
	File dir;
	String servername = "Webserver";
	BufferedReader in;
	BufferedOutputStream out;
	public Kommunikator(BufferedReader in_, BufferedOutputStream out_,File d) {	
		in = in_;
		out = out_;
		dir = d;
	}
	public void run() {// method of runnable
		try {
			communicate();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void communicate() throws java.io.IOException {
		String inq;
		HtttpInquiry inqu;
		try {
			inq = in.readLine();// reads the inquiry
			try {
				inqu = new HtttpInquiry(inq);//analyze the inquiry
			} catch (Exception e) {
				Terminal.printException(e);
				printError(400,"Error 400\nSyntax error of the inquiry");
				return;
			}
			Terminal.println(inqu.getInfoText());
			switch (inqu.getMethod()) {
				case "GET":
					String pth = inqu.getPath();
					if (pth.equals(DEBUG_TERMINAL_PATH)) {
						printTerminal();
						break;
					}
					if (pth.equals("/")) pth = "/index.html";
					printFile(pth);
					break;
				default:
					printError(501,"Error 501\nThe method " + inqu.getMethod() + " is not Implemented!");
			}
		} catch	(java.io.IOException e) {
			Terminal.printException(e);
			printError(500,"Error 500\nInternal Server Error\nError Message:\n" + e.getLocalizedMessage());
			return;
		}
	}
	private void printFile(String path) throws IOException {
		try {
			File file = new File(dir, path);
			if (!file.exists()) {
				printError(404,"Error 404\nFile not Found :(\nPath:" + path);
				return;
			}
			if (!file.isFile()) {
				printError(406,"Error 406\nThe requested file is a folder. the sending of folder contents was not permitted!\nPath:" + path);
				return;
			}
	//		byte[] filevalue = loadFile(file);
//			print(filevalue);
			printHaeder(200,file.length(), findDataType(file));
			printFileValue(file);
		} catch (IOException e) {
			e.printStackTrace();
			printError(406,"Error 406\nServer IOException: " + e.getMessage());
		}
	}
	private void printTerminal() throws IOException {
		byte[] terminalbytes = Terminal.toHtmlString().getBytes();
		printHaeder(200,terminalbytes.length, DATA_TYPES.get(".html"));
		print(terminalbytes);
	}
	private void print(byte[] b) throws IOException {
		out.write(b);
	}
	private void print(byte b) throws IOException {
		out.write(b);
	}
	private void printHaeder(int status,long length, String contentInfo) throws IOException{
		print(getHaeder(status,length,contentInfo).getBytes());
	}
	private String getHaeder(int status,long length, String contentInfo) {
		return "HTTP/1.0 " + status + " OK\r\n" + 
		"Date: " + new Date().toString() + "\r\n" +
		"Server: " + servername + "\r\n" +
		"Content-Type: " + contentInfo + "\r\n" +
		"Content-Length: " + length + "\r\n\r\n";
	}
	private void printError(int code, String message) throws IOException {
		byte[] messageBytes = message.getBytes();
		printHaeder(code,messageBytes.length,"text/plain; charset=utf-8");
		print(messageBytes);
	}
	private byte[] loadFile(File file) throws IOException{
			byte[] r = new byte[(int)file.length()];
			FileInputStream f = new FileInputStream(file);
			int a = 0;
			while (true) {
				int c = f.read();
				if (c == -1) {
					f.close();
					break;
				}
				r[a] = (byte)c;
				a++;
			}
			return r;
	}
	private void printFileValue(File file) throws IOException {
		FileInputStream f = new FileInputStream(file);
		while (true) {
			int c = f.read();
			if (c == -1) {
				f.close();
				break;
			}
			print((byte)c);
		}
	}
}