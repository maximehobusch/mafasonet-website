import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.TimeZone;
import java.net.URLDecoder;

class HtttpInquiry {//An HTTP request is analyzed here
	private String inq;
	
	private String method;
	private String url;
	private String httpVersion;

	private String path;
	private String paraString;
	private Hashtable<String,String> paras;
	
	private long time;
	HtttpInquiry(String inq_) {
		time = System.currentTimeMillis();
		inq = inq_;
		analyze();
	}
	String getInquiry() {// returns the entire request ("GET /test.html?blabla=dada&xx=yy HTTP/1.1" / ...)
		return inq;
	}
	String getMethod() {// returns the method ("GET" / ...)
		return method;
	}
	String getURL() {// returns the URL ("/test.html?blabla=dada&xx=yy" / ...)
		return url;
	}
	String getHTTPVersion() {// returns the http Version String ("HTTP/1.1" / ...)
		return httpVersion;
	}
	String getPath() {//returns the path ("/test.html" / ...)
		return path;
	}	
	String[] getParameterKeyArray() {// returns an Array of parameter keys (["blabla","xx"] / ...)
		Enumeration<String> en = paras.keys();
		ArrayList<String> arr = new ArrayList<String>();
		while (en.hasMoreElements()) {
			arr.add(en.nextElement());
		}
		String[] ret = new String[arr.size()];
		for (int i = 0; i < arr.size(); i++) {
			ret[i] = arr.get(i);
		}
		return ret;
	}
	String getParaValue(String key) {//returns the value of a parameter. if parameters have been duplicated, the first one is returned
		return paras.get(key);
	}
	String getInfoText() {
		return "[" + getDateText() + "] method:\"" + getMethod() + "\", url:\"" + getURL() + "\", HTTP-version:\"" + getHTTPVersion() + "\"";
	}
	private String getDateText() {
		Date date = new Date(time);
		TimeZone tz = TimeZone.getDefault();
		DateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss.SSS");
		df.setTimeZone(tz);
		return df.format(date) + " " + tz.getDisplayName();
	}
	private void analyze() {
		analyzeInq();
		analyzeUrl();
		analyzeParaString();
	}
	private void analyzeInq() {
		try {
			int space1 = inq.indexOf(' ',0);
			int space2 = inq.indexOf(' ',space1+1);
			method = inq.substring(0, space1);
			url = inq.substring(space1+1,space2);
			httpVersion = inq.substring(space2+1,inq.length());
		} catch (Exception e) {
			Terminal.println("Syntax Error in Inquiry \"" + inq + "\"");
			throw e;
		}
	}
	private void analyzeUrl() {
		int questionMark = url.indexOf('?');
		if (questionMark == -1) {
			path = url;
			paraString = "";
		} else {
			path = url.substring(0,questionMark);
			paraString = url.substring(questionMark+1,url.length());
		}
	}
	private void analyzeParaString() {
		paras = new Hashtable<String,String>();
		int i = 0;
		while (i < paraString.length()) {
			int equalSign = paraString.indexOf('=',i);
			if (equalSign == -1) return;
			int andSign = paraString.indexOf('&',equalSign+1);
			if (andSign == -1) andSign = paraString.length();
			paras.put(URLDecoder.decode(paraString.substring(i,equalSign)),URLDecoder.decode(paraString.substring(equalSign+1,andSign)));
			i = andSign+1;
		}
	}
}
