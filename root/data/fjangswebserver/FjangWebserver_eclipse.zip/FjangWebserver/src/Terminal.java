public class Terminal {// Wenn man keine ahnung hat, dass es sowas schon gibt...
	public static String TITLE = "Terminal";
	public static String value = "";	
	public static void printStackTrace(StackTraceElement[] e) {
		for (int a = 0; a < e.length; a++) {
			println(e[a].toString());
		}
	}
	public static void printException(Exception e) {
		println(e.toString());
		printStackTrace(e.getStackTrace());
	}
	public static void println(String s) {
		value = value + s + "\n";
		System.out.println(s);
	}
	public static void print(String s) {
		value = value + s;
		System.out.println(s);
	}
	public static String toHtmlString() {
		String s = "<html><body style=\"background-color:#000000; color:#FFFFFF\"><h1>" + TITLE + "</h1>";
		for (int a = 0; a < value.length(); a++) {
			char c = value.charAt(a);
			if (c == '\n') {
				s = s + "<br>";
			} else {
				s = s + c;
			}
		}
		return s + "</body></html>";
	}
}
